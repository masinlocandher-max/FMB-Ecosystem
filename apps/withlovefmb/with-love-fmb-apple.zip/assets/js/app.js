/* With love, FMB — interactions */
(function () {
  'use strict';

  /* Scroll reveals */
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reveals = document.querySelectorAll('.reveal');
  if (reduced || !('IntersectionObserver' in window)) {
    reveals.forEach(el => el.classList.add('in'));
  } else {
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(el => io.observe(el));
  }

  /* Nav state on scroll */
  const nav = document.getElementById('nav');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 24);
  }, { passive: true });

  /* Mobile menu */
  const toggle = document.getElementById('navToggle');
  const links = document.getElementById('navLinks');
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  links.addEventListener('click', e => {
    if (e.target.tagName === 'A') {
      links.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  });

  /* Hero video: respect reduced motion, offer pause */
  const video = document.getElementById('heroVideo');
  const vToggle = document.getElementById('videoToggle');
  const icPause = vToggle.querySelector('.ic-pause');
  const icPlay = vToggle.querySelector('.ic-play');
  if (reduced) { video.pause(); icPause.hidden = true; icPlay.hidden = false; vToggle.setAttribute('aria-pressed', 'true'); }
  vToggle.addEventListener('click', () => {
    if (video.paused) {
      video.play(); icPause.hidden = false; icPlay.hidden = true;
      vToggle.setAttribute('aria-pressed', 'false');
      vToggle.setAttribute('aria-label', 'Pause background video');
    } else {
      video.pause(); icPause.hidden = true; icPlay.hidden = false;
      vToggle.setAttribute('aria-pressed', 'true');
      vToggle.setAttribute('aria-label', 'Play background video');
    }
  });

  /* Contact form — front-end only until a backend is connected */
  const form = document.getElementById('contactForm');
  const note = document.getElementById('formNote');
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!form.checkValidity()) {
      note.textContent = 'Please fill in your name, a valid email, and a message.';
      return;
    }
    note.textContent = 'The form isn’t connected yet — connect Formspree or Netlify Forms before launch.';
  });
})();


/* ===== Unspoken Thoughts flow (front-end preview; connect Supabase + email service for launch) ===== */
(function () {
  const $ = id => document.getElementById(id);
  const s1 = $('uStep1'), s2 = $('uStep2'), s3 = $('uStep3');
  if (!s1) return;
  const thought = $('uThought'), count = $('uCount');
  thought.addEventListener('input', () => { count.textContent = thought.value.length; });

  $('uSend').addEventListener('click', () => {
    const email = $('uEmail').value.trim();
    const note = $('uNote1');
    if (thought.value.trim().length < 3) { note.textContent = 'Write your thought first — even a short one counts.'; return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { note.textContent = 'Please enter a working email so we can send your code.'; return; }
    note.textContent = '';
    $('uEmailEcho').textContent = email;
    s1.hidden = true; s2.hidden = false;
    $('uCode').focus();
  });

  $('uBack').addEventListener('click', () => { s2.hidden = true; s1.hidden = false; });

  $('uVerify').addEventListener('click', () => {
    const code = $('uCode').value.trim();
    const note = $('uNote2');
    if (!/^\d{6}$/.test(code)) { note.textContent = 'The code is 6 digits — check your inbox.'; return; }
    note.textContent = '';
    s2.hidden = true; s3.hidden = false;
  });

  $('uAgain').addEventListener('click', () => {
    thought.value = ''; count.textContent = '0'; $('uCode').value = '';
    s3.hidden = true; s1.hidden = false;
    thought.focus();
  });
})();

/* ===== Sinag — message companion (scripted preview; swap in a real conversational backend before launch) ===== */
(function () {
  const fab = document.getElementById('chatFab');
  const panel = document.getElementById('chatPanel');
  if (!fab) return;
  const body = document.getElementById('chatBody');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatText');

  fab.addEventListener('click', () => {
    const open = panel.hidden;
    panel.hidden = !open;
    fab.setAttribute('aria-expanded', String(open));
    if (open) input.focus();
  });
  document.getElementById('chatClose').addEventListener('click', () => {
    panel.hidden = true; fab.setAttribute('aria-expanded', 'false');
  });

  const add = (text, cls) => {
    const d = document.createElement('div');
    d.className = 'msg ' + cls;
    d.textContent = text;
    body.appendChild(d);
    body.scrollTop = body.scrollHeight;
  };

  const rules = [
    { re: /(sad|lonely|malungkot|cry|iyak|down|depress)/i, replies: [
      'That sounds heavy, and I’m glad you said it here instead of carrying it alone. Whatever it is, it doesn’t make you less.',
      'You don’t have to make it sound smaller than it feels. Nandito lang ako. If it stays heavy, please also reach for someone you trust or a professional — you deserve real support.'
    ]},
    { re: /(tired|pagod|exhaust|burnout)/i, replies: [
      'Pagod is information, not weakness. What’s one small thing you could set down today — even just for tonight?',
      'Rest is not something you have to earn. You’re allowed to stop before you break.'
    ]},
    { re: /(happy|masaya|proud|excited|good news)/i, replies: [
      'I love that. Say it again, louder to yourself this time — you’re allowed to enjoy your own good news.',
      'That’s worth keeping. Write it somewhere you’ll find it on a harder day.'
    ]},
    { re: /(scared|afraid|takot|anxious|kaba|worried)/i, replies: [
      'Fear usually means something matters to you. You can be scared and still move — slowly counts.',
      'You don’t have to be fearless. You just have to be honest, and you already are.'
    ]},
    { re: /(who are you|ano ka|real person|human|totoo ka|ai ka|bot)/i, replies: [
      'I’m Sinag — a digital companion built for this corner of the internet, not a real person. But the care behind this space is real, and so is the person who made it.'
    ]},
    { re: /(thank|salamat)/i, replies: [
      'Walang anuman. Come back anytime — this corner keeps a seat for you.'
    ]}
  ];
  const fallback = [
    'I hear you. Tell me more, or just leave it here — both are okay.',
    'Thank you for saying that out loud. What would feel lighter after saying it?',
    'You’re allowed to be exactly where you are right now. Walang deadline ang pagiging tao.',
    'That’s worth sitting with. If you want, you can release it in Unspoken Thoughts above — anonymously if you prefer.'
  ];
  let fi = 0;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    add(text, 'msg-out');
    input.value = '';
    const rule = rules.find(r => r.re.test(text));
    const reply = rule ? rule.replies[Math.floor(Math.random() * rule.replies.length)]
                       : fallback[fi++ % fallback.length];
    setTimeout(() => add(reply, 'msg-in'), 700 + Math.random() * 600);
  });
})();
